#ifndef INFOGRAPHICS_H
#define INFOGRAPHICS_H
#include<iostream>
using namespace std;

class Infographic
{
    private:
       string title;
       string image;
    public:
        void viewInfographic()
        {
            //fikir balik
        }
};


