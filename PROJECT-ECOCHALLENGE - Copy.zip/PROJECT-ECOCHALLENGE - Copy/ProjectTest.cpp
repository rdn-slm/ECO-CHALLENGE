//ni tempat fork project
#include <iostream>
#include <iomanip>
#include <list>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <ctime>
#include <windows.h>
#include "EducationalContent.h"

using namespace std;

class